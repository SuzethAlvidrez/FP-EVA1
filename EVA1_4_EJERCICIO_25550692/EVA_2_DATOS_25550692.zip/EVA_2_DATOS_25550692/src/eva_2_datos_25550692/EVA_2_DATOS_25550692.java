/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva_2_datos_25550692;

/**
 *
 * @author suzet
 */
public class EVA_2_DATOS_25550692 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //;significa fin de linea
        //"  " =cadena de texto. dato
        System.out.println("SUZETH ALVIDREZ");
        //Numeros
        System.out.println(1000);
        //Numeros decimales
        System.out.println(500.3);
        //valores logicos(verdadero o falso)
        //true or false
        System.out.println(true);
        //Caracteres individuales
        //cosas distintas
        System.out.println('c'); //Caracter
        System.out.println("c"); ///Cadena de texto 
        

        
    }
    
}
